import 'package:flutter/widgets.dart';
class NoomiKeys {
  static final navKey =  GlobalKey<NavigatorState>();
}